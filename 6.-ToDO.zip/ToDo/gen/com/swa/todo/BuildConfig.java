/** Automatically generated file. DO NOT MODIFY */
package com.swa.todo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}